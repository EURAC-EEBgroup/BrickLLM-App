from .graphs import BrickSchemaGraph

# compiled graph
brickschema_graph = BrickSchemaGraph()._compiled_graph()
