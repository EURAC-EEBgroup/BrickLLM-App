<p align="center">
  <img src="docs/assets/brickllm_logo.png" alt="BrickLLM" style="width: 100%;">
</p>

# Local test
generate virutalenvironemnt 
```
cd /Users/dantonucci/.pyenv/versions
source venv_frontend/bin/activate
cd /Users/dantonucci/Library/CloudStorage/OneDrive-ScientificNetworkSouthTyrol/00_GitHubProject/benchmarking_geoapp/brickllm-lib-main

```

Create library:

```
  poetry install
  poetry build
```

in folder /dist:

```
  cd dist
  pip install brickllm-0.0.1.tar.gz

```