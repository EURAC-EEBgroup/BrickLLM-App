from .graphs import BrickSchemaGraph

brickschema_graph = BrickSchemaGraph()._compiled_graph()